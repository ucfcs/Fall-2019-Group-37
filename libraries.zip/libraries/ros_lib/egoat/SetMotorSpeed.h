#ifndef _ROS_egoat_SetMotorSpeed_h
#define _ROS_egoat_SetMotorSpeed_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace egoat
{

  class SetMotorSpeed : public ros::Msg
  {
    public:
      typedef int8_t _left_motor_type;
      _left_motor_type left_motor;
      typedef int8_t _right_motor_type;
      _right_motor_type right_motor;

    SetMotorSpeed():
      left_motor(0),
      right_motor(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        int8_t real;
        uint8_t base;
      } u_left_motor;
      u_left_motor.real = this->left_motor;
      *(outbuffer + offset + 0) = (u_left_motor.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->left_motor);
      union {
        int8_t real;
        uint8_t base;
      } u_right_motor;
      u_right_motor.real = this->right_motor;
      *(outbuffer + offset + 0) = (u_right_motor.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->right_motor);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        int8_t real;
        uint8_t base;
      } u_left_motor;
      u_left_motor.base = 0;
      u_left_motor.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->left_motor = u_left_motor.real;
      offset += sizeof(this->left_motor);
      union {
        int8_t real;
        uint8_t base;
      } u_right_motor;
      u_right_motor.base = 0;
      u_right_motor.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->right_motor = u_right_motor.real;
      offset += sizeof(this->right_motor);
     return offset;
    }

    const char * getType(){ return "egoat/SetMotorSpeed"; };
    const char * getMD5(){ return "2cf4c08495944ee0a8011eaf1b538966"; };

  };

}
#endif
